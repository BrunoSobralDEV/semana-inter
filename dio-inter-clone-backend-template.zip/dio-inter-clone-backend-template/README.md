- Requisitos e ambiente 

- Visual Studio Code
  Extensões:
- Insomnia ou Postman


---
Dependencias nescessárias

Express
typescript -D
ts-node -D 
@types/express -D
@types/node -D
nodemon -D


Criando setup Ininical - Referencias.
https://dev.to/melquisedecfelipe/configurando-eslint-no-node-com-express-e-typescript-58p9
